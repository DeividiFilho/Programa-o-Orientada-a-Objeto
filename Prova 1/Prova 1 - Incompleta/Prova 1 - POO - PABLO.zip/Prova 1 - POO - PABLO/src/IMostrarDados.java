public interface IMostrarDados {
    void MostrarDados();
}
