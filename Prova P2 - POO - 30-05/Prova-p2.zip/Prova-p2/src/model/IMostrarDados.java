package model;

public interface IMostrarDados {
    void mostrarDados();
}
